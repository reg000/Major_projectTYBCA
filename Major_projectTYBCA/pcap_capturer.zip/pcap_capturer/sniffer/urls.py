from django.urls import path
from .views import start_sniffing_api, stop_sniffing_api

urlpatterns = [
    path('start-sniffing/', start_sniffing_api, name='start-sniffing'),
    path('stop-sniffing/', stop_sniffing_api, name='stop-sniffing'),
]
