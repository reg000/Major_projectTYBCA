from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .sniffer import start_sniffing, stop_sniffing
import threading

sniffing_thread = None 

@csrf_exempt
def start_sniffing_api(request):
    global sniffing_thread
    if sniffing_thread and sniffing_thread.is_alive():
        return JsonResponse({'status': 'error', 'message': 'Sniffing is already running'})
    
    sniffing_thread = threading.Thread(target=start_sniffing, daemon=True)
    sniffing_thread.start()
    
    return JsonResponse({'status': 'success', 'message': 'Sniffing started'})

@csrf_exempt
def stop_sniffing_api(request):
    packets = stop_sniffing()
    if len(packets) == 0:
        return JsonResponse({"message": "No packets captured."}, status=200)
    return JsonResponse({'status': 'success', 'packets': packets})

