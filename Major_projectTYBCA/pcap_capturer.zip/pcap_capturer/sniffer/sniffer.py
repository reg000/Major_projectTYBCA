from scapy.all import sniff
import threading
import time

captured_packets = []  

def process_packet(packet):
    """Extracts metadata from packets and stores it."""
    packet_info = {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'src_ip': packet[0].src if packet.haslayer('IP') else None,
        'dst_ip': packet[0].dst if packet.haslayer('IP') else None,
        'src_mac': packet.src if hasattr(packet, 'src') else None,
        'dst_mac': packet.dst if hasattr(packet, 'dst') else None,
        'src_port': packet.sport if hasattr(packet, 'sport') else None,
        'dst_port': packet.dport if hasattr(packet, 'dport') else None,
        'protocol': packet.proto if hasattr(packet, 'proto') else None,
        'summary': packet.summary(),
    }
    print(f"Captured packet: {packet_info}")
    captured_packets.append(packet_info)

def start_sniffing():
    sniff(prn=process_packet, store=False)

def stop_sniffing():
    global captured_packets
    packets = captured_packets.copy()
    captured_packets = []  
    return packets 
